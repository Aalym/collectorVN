const characters = {
  hero: {
    name: "hero",
    img: "src/assets/chars/hero.jpg",
  },
  collector: {
    name: "Коллектор",
    img: "src/assets/chars/Test_collector.png",
  },
  friend: {
    name: "Подруга",
    img: "/src/chars/friend.png",
  },
};

export default characters;
